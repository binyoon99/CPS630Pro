<?php

include('connection.php');

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

$query = "INSERT INTO user (name, email, password) VALUES ('$name', '$email', '$password')";

if (mysqli_query($conn,$query)) {
    echo 'success inserting';
} else {
    echo "error: " . mysqli_error($conn);
}

$conn->close();

?>